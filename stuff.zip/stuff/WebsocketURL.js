
export const FlaskConnection = {IP:'localhost', port:5000};
export const FlaskConnection2 = {IP:'localhost', port:5001};